using AccountsManager.services;
using AccountsManager.Listners;
using AccountsManager.publisher.operations;
using AccountsManager.Models;
using AccountsManager.repository;

namespace AccountsManager.publisher;

public class AccountDepartment : FundTransferOperation
{
    List<Account> accounts { get; set; }
    NotificationService service;

    public AccountDepartment(List<Account> accounts, NotificationService notificationService)
    {
        this.service = notificationService;
        this.accounts = accounts;
    }
    AccountRepository accountRepository = new AccountRepository();
    OperationsRepository operationsRepository = new OperationsRepository();
    public List<AccountListener> listeners = new List<AccountListener>();


    public double getBalance(int AccountNo)
    {
        foreach (Account account in accounts)
        {
            if (account.AccountNo == AccountNo)
            {
                account.lastTransaction = DateTime.Now;
                Console.WriteLine($"Balance in account with id {account.AccHolderName}is {account.balance}");
                accountRepository.SaveAllAccounts(accounts);

                return account.balance;
            }

        }
        return 0;
    }

    public void deposit(double AccountNo, double amount)
{
    foreach (Account account in accounts)
    {
        if (account.AccountNo == AccountNo)
        {
            account.balance += amount;
            account.lastTransaction = DateTime.Now;

            Console.WriteLine($"Balance in account with id {account.AccountNo} after deposit is {account.balance}");

            checkBalance(account);

            accountRepository.SaveAllAccounts(accounts);

            break;
        }
    }
}
    public void withdraw(double AccountNo, double amount)
{
    foreach (Account account in accounts)
    {
        if (account.AccountNo == AccountNo)
        {
            account.balance -= amount;
            account.lastTransaction = DateTime.Now;

            Console.WriteLine(
                $"Balance in account with id {account.AccountNo} after withdraw is {account.balance}");

            accountRepository.SaveAllAccounts(accounts);

            break;
        }
    }
}


    public void checkBalance(Account a)
    {
        if (a.balance < 1000)
        {
            foreach (AccountListener l in listeners)
            {
                l.onOverBalance(a.balance);
                service.send("Amount Less Than Minimum Balance Policy");
            }
        }

        if (a.balance > 250000)
        {
            foreach (AccountListener l in listeners)
            {
                l.onOverBalance(a.balance);
                service.send("Amount is greater than  Taxable income policy");
            }
        }
    }

public void FundTransfer(double fromAccount,double toAccount,double amount)
{
    Account? sender = null;
    Account? receiver = null;

    foreach (Account a in accounts)
    {
        if (a.AccountNo == fromAccount)
        sender = a;

        if (a.AccountNo == toAccount)
            receiver = a;
    }

    if (sender == null || receiver == null)
    {
        Console.WriteLine("Account Not Found");
        return;
    }

    if (sender.balance < amount)
    {
        Console.WriteLine("Insufficient Balance");
        return;
    }

    withdraw(fromAccount, amount);

    deposit(toAccount, amount);

    Operations operation = new Operations()
    {
        DebitAccNo = fromAccount,
        creditAccNo = toAccount,
        amount = amount,
        Transactiontime = DateTime.Now
    };

    List<Operations> operations = operationsRepository.GetAllOperations();

    operations.Add(operation);

    operationsRepository.SaveAllOperations(operations);

    Console.WriteLine("Transfer Successful");
}

    // public void FundTransfer(double fromAccout, double ToAccount, double amount)

    // {
    //     foreach (Account account in accounts)
    //     {
    //         if (account.AccountNo == fromAccout)
    //         {
    //             withdraw(fromAccout, amount);
    //             account.lastTransaction = DateTime.Now;
    //             accountRepository.SaveAllAccounts(accounts);
    //             Console.WriteLine($"Balance in account with id {account.AccountNo} after Withdraw is {account.balance}");
         
    //         }
    //     }

    //     foreach (Account a in accounts)
    //     {
    //         if (a.AccountNo == ToAccount)
    //         {
    //             deposit(ToAccount, amount);
    //             a.lastTransaction = DateTime.Now;
    //             accountRepository.SaveAllAccounts(accounts);
    //             Console.WriteLine($"Balance in account with id {a.AccountNo} after Withdraw is {a.balance}");
           
    //         }
    //     }


    

    public void addListener(AccountListener listener)
    {
        listeners.Add(listener);

    }


}